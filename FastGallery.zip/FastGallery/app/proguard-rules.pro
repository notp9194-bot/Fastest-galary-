# Default rules kaafi hain.
